<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Patch</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Téléchargements des patchs de traduction en français de Fate/Stay Night [Réalta Nua].">
    <link rel="stylesheet" href="main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <?php include("./social.php"); ?>
    <section id="main">    
      <h1>Patchs</h1>
      <p>
        Patchs conçus pour fonctionner avec Fate／stay night[Réalta Nua] Ultimate Edition (0.9.1)<br>
        <a href="https://github.com/FSN-TRAD/FSN-FR/releases/latest">Téléchargement des patchs sur github</a>
        <br>
      </p>

      <hr>

      <h2>Tutoriels d'installation</h2>
      <div class="tuto-list">
        <div class="tuto-container">
          <a href="https://archetype-moon.fr/installer-fate-stay-night-sur-windows-et-android#windows" target="_blank" class="tuto">
            Windows
          </a>
          <div class="tuto-author">par Archetype:Moon</div>
        </div>

        <div class="tuto-container">
          <a href="https://archetype-moon.fr/installer-fate-stay-night-sur-windows-et-android#android" target="_blank" class="tuto">
            Android
          </a>
          <div class="tuto-author">par Archetype:Moon</div>
        </div>

        <div class="tuto-container">
          <a href="https://docs.google.com/document/d/1RKth0eUm_80vrDvt1FAaoE3qPfXmGZnb/edit" target="_blank" class="tuto">
            macOS
          </a>
          <div class="tuto-author"><a href="https://forums.nrvnqsr.com/member.php/12622-RadonCRM" target="blank_">par RadonCRM</a></div>
        </div>
      
      </div>

      <hr>

      <p>
        L'ultimate Edition vous propose plusieurs <a href="options.php">options</a>
        pour améliorer votre expérience de jeu.<br>
        <br>
      </p>

    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
