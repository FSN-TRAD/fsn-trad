<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Patch</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Téléchargements des patchs de traduction en français de Fate/Stay Night [Réalta Nua].">
    <link rel="stylesheet" href="main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <section id="main">    
      <h1>Patchs</h1>
      <p>
        Patchs conçus pour fonctionner avec Fate／stay night[Réalta Nua] Ultimate Edition (0.9.1)<br>
        <a href="https://github.com/FSN-TRAD/FSN-FR/releases/latest">Téléchargement des patchs sur github</a>
        <br>
      </p>

      <hr>

      <h2>Tutoriels d'installation</h2>
      <p>
        <a href="https://archetype-moon.fr/installer-fate-stay-night-sur-windows-et-android" target="_blank">Windows + Android</a><br>
        <a href="https://docs.google.com/document/d/1RKth0eUm_80vrDvt1FAaoE3qPfXmGZnb/edit" target="_blank">macOS</a>
        (par <a href="https://forums.nrvnqsr.com/member.php/12622-RadonCRM" target="blank_">RadonCRM</a>)
        <br>
      </p>

    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
