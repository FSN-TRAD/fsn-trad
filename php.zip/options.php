<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Options</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Présentation des options de l'Ultimate Edition.">
    <meta property="og:image" content="https://fsn-trad.github.io/website/images/logo_fsn-trad_small.png" />
	  <meta name="theme-color" content="#0b3f71">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <?php include("./social.php"); ?>
    <section id="main">
      <h1>Options du patch</h1>
      <hr/>

      <p>
      <h2>Langue</h2>
      Utilisez ce bouton pour changer la langue du jeu. La configuration des polices est sauvegardée par langue,
      vous pouvez donc définir votre police préférée par langue.

      <h2>Patch</h2>
      <ul>
        <li><h3>Contenu textuel</h3>
          <ul>
            <li>Réalta Nua : les textes du jeu correspondent à ceux de la version PC de RN.</li>
            <li>Mix : les textes du jeu sont un mélange de la version Réalta Nua et de la version Classique.</li>
            <li>Classique : les textes de la version classique de 2004.</li>
          </ul>
        </li>
        <li><h3>Musique</h3>
          <ul>
            <li>Fonctionne de la même façon que Contenu Textuel, mais pour les musiques.</li>
          </ul>
        </li>
        <li><h3>Censure</h3>
          <ul>Seule une de ces trois options suivantes peut être sélectionnée.
            <li>Censure le contenu H : remplace les scènes H par des scènes alternatives, censure la nudité, cache ces scènes
              des menus et de la galerie.</li>
            <li>Affiche le contenu H : affiche toutes les scènes H et la nudité. Avec cette option vous pouvez voir les
              scènes H et leur scène alternative dans le menu et la galerie.</li>
            <li>Affiche le contenu H décensuré : fonctionne comme l’option “Affiche le contenu H” mais enlève les mosaïques
              de censure (fanmade).</li><br>
            <li>Censure le contenu mature : les textes comprenant des contenus adultes tels que la consommation d'alcool par
              des mineurs, la violence extrême, le gore et les thèmes sexuels.</li>
          </ul>
        </li>
        <li><h3>Voix</h3>
          <ul>
            <li>Jouer les voix désynchronisées : En raison de la censure effectuée sur les scripts de la version vita,
              certaines voix ne correspondent pas au texte. Si vous ne connaissez pas le japonais, vous devriez probablement
              cocher cette option, car la plupart du temps, le ton correspond à l'atmosphère.</li>
            <li>Jouer les voix inutilisées : certaines voix existent dans les fichiers du jeu mais ne sont pas jouées dans
              les versions officielles du jeu. Ce paramètre vous permet de les jouer.</li>
            <li>Utiliser des tags de voix personnalisés : la version vita propose un bel effet où le texte attend que la voix
              atteigne un certain point avant de jouer certains effets spéciaux. Lors de l'insertion des voix, certaines personnes
              ont ajouté leurs propres balises d'attente de voix personnalisées pour améliorer l'expérience dans les endroits où
              elles étaient absentes. Cette option est uniquement pour les balises personnalisées. Nous recommandons de la garder
              activée.</li>
            <li>Réduire le volume des musiques pendant les dialogues : réduit légèrement le volume des musiques lorsqu’un
              personnage est en train de parler.</li>
            <li>Utiliser des icônes de voix personnalisées pour les replay : affiche dans l’historique des icônes spécifiques aux
              personnages pour le bouton de lecture de la voix au lieu du bouton générique.</li>
            <li>Ne pas arrêter les voix après un clic : lorsque vous passez à la phrase suivante, la voix que vous écoutiez n’est
              pas interrompue.</li>
            <li>Langue des incantations de Rin : à certains moments de l’histoire, les incantations de Rin ont été doublées en
              japonais (PS2) et en Allemand (PC version RN).</li>
          </ul>
        </li>
        <li><h3>Additions Vita</h3>
          <ul>
            <li>Utiliser les OP Vita : joue les opening plus récents de la version Vita plutôt que les originaux.</li>
            <li>Menu “vidéos” Vita : ajoute les opening Vita au menu Vidéos.</li>
            <li>Menu “À propos” Vita : utilise l’arrière plan Vita pour le menu “À propos”.</li>
          </ul>
        </li>
        <li><h3>Galerie</h3>
          <ul>
            <li>Galerie étendue : ajoute à la galerie plus de CGs de la version classique de 2004 et PS2 du jeu.</li>
            <li>Fusion des galeries : enlève certaines CGs dupliquées entre les routes et les réarrange à la façon de la version
              PS2 du jeu.</li>
            <li>Miniatures en haute qualité : génère dynamiquement les miniatures de la galerie. Le rendu est plus beau mais
              prend un peu plus de temps.</li>
          </ul>
        </li>
        <li><h3>Vidéos</h3>
          <ul>
            <li>Afficher les sous-titres dans les vidéos</li>
            <li>Sauter les vidéos en jeu : si les vidéos sont la cause de crash, cette option permet de les passer.</li>
            <li>Forcer l’utilisation de mpv pour les vidéos : cochez cette option si vous avez des problèmes à la lecture des vidéos.</li>
          </ul>
        </li>
        <li><h3>Options</h3>
          <ul>
            <li>Afficher le titre des scènes dans l’historique : le titre de la scène en cours sera affiché en haut de l’écran dans
              l’historique. Attention aux spoilers.</li>
            <li>Menu titre prologue : le jeu commence sans menu titre jusqu’à ce que vous ayez terminé le prologue. Seulement la version
              PS2 disposait d’un menu de prologue, et cette option le restaure.</li>
            <li>Désactiver la lecture auto. forcée : à un certain moment du jeu, il y a un texte où la lecture auto. est forcée.
              Cette option la désactive.</li>
          </ul>
        </li>
        <li><h3>Fenêtre de texte</h3>
          <ul>
            <li>Glyphes de fin de ligne pour mobiles : utilise le glyphe de fin de ligne de la version mobile (le curseur animé qui
              attend une action de votre part) de la version mobile.</li>
            <li>Cadre de texte pour mobiles : utilise la fenêtre de texte de la version mobile.</li>
            <li>Fenêtre de texte 4:3 en mode étendu : utilise une fenêtre de texte à la taille classique à la place d’une élargie.</li>
          </ul>
        </li>
      </ul>

      </p>
    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
