<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Patch</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Téléchargements des patchs de traduction en français de Fate/Stay Night [Réalta Nua].">
    <meta property="og:image" content="https://fsn-trad.github.io/website/images/logo_fsn-trad_small.png" />
	  <meta name="theme-color" content="#0b3f71">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/patch.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <?php include("./social.php"); ?>
    <section id="main">    


      <h2>Tutoriels d'installation</h2>
      <div class="tuto-list">
        <div class="tuto-container">
          <a href="https://archetype-moon.fr/installer-fate-stay-night-sur-windows-et-android#windows" target="_blank" class="btn-grad">
            Windows
          </a>
          <div class="tuto-author">par Archetype:Moon</div>
        </div>

        <div class="tuto-container">
          <a href="https://archetype-moon.fr/installer-fate-stay-night-sur-windows-et-android#android" target="_blank" class="btn-grad">
            Android
          </a>
          <div class="tuto-author">par Archetype:Moon</div>
        </div>

        <div class="tuto-container">
          <a href="https://docs.google.com/document/d/1RKth0eUm_80vrDvt1FAaoE3qPfXmGZnb/edit" target="_blank" class="btn-grad">
            macOS
          </a>
          <div class="tuto-author"><a href="https://forums.nrvnqsr.com/member.php/12622-RadonCRM" target="blank_">par RadonCRM</a></div>
        </div>
      </div>

      <hr>

      <h1>Patch</h1>
      <p>
        Patch conçu pour fonctionner avec Fate／stay night [Réalta Nua] Ultimate Edition (0.9.1)<br>
        <a href="https://github.com/FSN-TRAD/FSN-FR/releases/latest">Téléchargement du patch sur github</a>
        <br>
      </p>

      <p>
        L'ultimate Edition vous propose plusieurs <a href="options.php">options</a>
        pour améliorer votre expérience de jeu.<br>
      </p>

    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
