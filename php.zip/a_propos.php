<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>À propos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Mentions du projet de traduction de Fate/stay night [Réalta Nua].">
    <link rel="stylesheet" href="main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <section id="main">
      <h1>À propos</h1>
      <hr/>
      <ul class="team-list">
        <li><h3>Chef de projet</h3>
          <ul>
            <li>MaxiDiamond</li>
          </ul>
        </li>
        <li><h3>Traduction</h3>
          <ul>
            <li>MaxiDiamond</li>
            <li>Alucardonac Mono</li>
            <li>Toubib</li>
            <li>Le Chauve Capé</li>
          </ul>
        </li>
        <li><h3>Relecture</h3>
          <ul>
            <li>Caster</li>
            <li>RequinDr</li>
            <li>loicfr</li>
          </ul>
        </li>
        <li><h3>Retouche graphique</h3>
          <ul>
            <li>MaxiDiamond</li>
          </ul>
        </li>
        <li><h3>Programmation/Outils</h3>
          <ul>
            <li>Le Chauve Capé</li>
            <li>MaxiDiamond</li>
            <li>RequinDr</li>
            <li>loicfr</li>
          </ul>
        </li>
        <li><h3>Remerciements</h3>
          <ul>
            <li>LucasPC</li>
            <li>RAYTEK</li>
            <li>FBates, nouvelle traduction anglaise</li>
            <li>Alyinghood, UE</li>
            <li>Quibi, UE</li>
            <li>Bohemian Waxwing, UE</li>
          </ul>
        </li>
      </ul>
      <hr/>
      <p>
        Les logos et le jeu sont la propriété de Type-Moon. Pour utiliser ce patch de traduction vous devez posséder la version originale du jeu.
      </p>
      <!--<p>
        Le site est hébergé par OVH. 2 rue Kellermann - 59100 Roubaix - France.<br/>
        Le site utilise des cookies à des fins de statistiques. Les données sont anonymisées et stockées sur le serveur du site. Elles ne seront communiquées à aucun tiers. L'adresse IP du visiteur peut être conservée dans les logs du serveur.
      </p>-->
    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
