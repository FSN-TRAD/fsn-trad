<footer>
  ©2022 FSN-TRAD
  <picture>
    <source srcset="images/logo_fsn-trad_small.webp" type="image/webp">
    <source srcset="images/logo_fsn-trad_small.jpg" type="image/jpg"> 
    <img class="visuel" src="images/logo_fsn-trad_small.webp" alt="Logo FSN-TRAD" id="logo_trad">
	</picture>
</footer>
