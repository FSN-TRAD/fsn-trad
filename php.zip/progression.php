<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Progression</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Pour connaître l'avancement de la traduction, c'est ici.">
    <meta property="og:image" content="https://fsn-trad.github.io/website/images/logo_fsn-trad_small.png" />
	  <meta name="theme-color" content="#0b3f71">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/progression.css">
    <script type="text/javascript" src="scripts/progressbar.min.js"></script>
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <?php include("./social.php"); ?>
    <section id="main">
      <h1>Progression de la traduction</h1>
      <hr/>
      <div id="progression">
        <div id="progression-fate"><h2>Fate</h2>
        <?php
          $fate_progress = array(
            ['day' => 'Jour 1', 'now' => 7, 'total' => 7],
            ['day' => 'Jour 2', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 3', 'now' => 11, 'total' => 11],
            ['day' => 'Jour 4', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 5', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 6', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 7', 'now' => 3, 'total' => 3],
            ['day' => 'Jour 8', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 9', 'now' => 7, 'total' => 7],
            ['day' => 'Jour 10', 'now' => 4, 'total' => 4],
            ['day' => 'Jour 11', 'now' => 10, 'total' => 10],
            ['day' => 'Jour 12', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 13', 'now' => 10, 'total' => 10],
            ['day' => 'Jour 14', 'now' => 7, 'total' => 7],
            ['day' => 'Jour 15', 'now' => 11, 'total' => 11],
            ['day' => 'Épilogue', 'now' => 1, 'total' => 1],
            ['day' => 'Tiger Dojo', 'now' => 14, 'total' => 14]
          );
          // Affiche le pourcentage de progression
          echo '<div id="container_fate" class="container"></div>';

          // Affiche chaque jour et la barre de progression
          foreach($fate_progress as $cle => $valeur) {
            displayProgress($fate_progress[$cle]['day'], $fate_progress[$cle]['now'], $fate_progress[$cle]['total']);
          }
          ?>
        </div>
        <div id="progression-ubw"><h2>Unlimited Blade Works</h2>
          <?php
          $ubw_progress = array(
            ['day' => 'Jour 3', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 4', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 5', 'now' => 10, 'total' => 10],
            ['day' => 'Jour 6', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 7', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 8', 'now' => 7, 'total' => 7],
            ['day' => 'Jour 9', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 10', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 11', 'now' => 10, 'total' => 10],
            ['day' => 'Jour 12', 'now' => 7, 'total' => 8],
            ['day' => 'Jour 13', 'now' => 0, 'total' => 8],
            ['day' => 'Jour 14', 'now' => 8, 'total' => 8],
            ['day' => 'Jour 15', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 16', 'now' => 10, 'total' => 10],
            ['day' => 'Épilogue', 'now' => 0, 'total' => 2],
            ['day' => 'Tiger Dojo', 'now' => 8, 'total' => 10]
          );
          // Affiche le pourcentage de progression
          echo '<div id="container_ubw" class="container"></div>';

          // Affiche chaque jour et la barre de progression
          foreach($ubw_progress as $cle => $valeur) {
            displayProgress($ubw_progress[$cle]['day'], $ubw_progress[$cle]['now'], $ubw_progress[$cle]['total']);
          }
          ?>
        </div>
        <div id="progression-hf"><h2>Heaven's Feel</h2>
          <?php
          $hf_progress = array(
            ['day' => 'Jour 4', 'now' => 0, 'total' => 7],
            ['day' => 'Jour 5', 'now' => 0, 'total' => 12],
            ['day' => 'Jour 6', 'now' => 0, 'total' => 9],
            ['day' => 'Jour 7', 'now' => 0, 'total' => 11],
            ['day' => 'Jour 8', 'now' => 0, 'total' => 10],
            ['day' => 'Jour 9', 'now' => 0, 'total' => 14],
            ['day' => 'Jour 10', 'now' => 0, 'total' => 14],
            ['day' => 'Jour 11', 'now' => 0, 'total' => 10],
            ['day' => 'Jour 12', 'now' => 0, 'total' => 7],
            ['day' => 'Jour 13', 'now' => 0, 'total' => 6],
            ['day' => 'Jour 14', 'now' => 0, 'total' => 6],
            ['day' => 'Jour 15', 'now' => 0, 'total' => 13],
            ['day' => 'Jour 16', 'now' => 0, 'total' => 14],
            ['day' => 'Épilogue', 'now' => 0, 'total' => 2],
            ['day' => 'Tiger Dojo', 'now' => 0, 'total' => 16]
          );
          // Affiche le pourcentage de progression
          echo '<div id="container_hf" class="container"></div>';
          
          // Affiche chaque jour et la barre de progression
          foreach($hf_progress as $cle => $valeur) {
            displayProgress($hf_progress[$cle]['day'], $hf_progress[$cle]['now'], $hf_progress[$cle]['total']);
          }
          ?>
        </div>
        <div class="flex-break"></div>

        <div class="progression-bottom-container">
          <div class="progression-bottom">
            <div id="container_pro" class="container"></div>
            Prologue
          </div>
          <div class="progression-bottom">
            <div id="container_le" class="container"></div>
            Last Episode
          </div>
        </div>
      </div>
    </section>
    <?php include("./footer.php") ?>
  </body>
</html>

<?php
function displayProgress($jour, $fait, $total){
  echo "
  <div class=\"barre-prog\">
    <div class=\"pb-text-wrapper\">
      <span>" . $jour . "</span>
      <span class=\"pb-text\">". round(($fait/$total*100)) ." %</span>
    </div>
    <div class=\"pb-wrapper\">
      <div class=\"pb-bar\" style=\"width:". ($fait/$total)*100 ."%\"></div>
    </div>
  </div>";
}
function displayProgressH2($H2, $fait, $total){
  echo "<div class=\"pb-text-wrapper\">
    <h2>" . $H2 . "</h2>
    <span class=\"pb-text\">".$fait."/".$total."</span>
  </div>
  <div class=\"pb-wrapper\">
    <div class=\"pb-bar\" style=\"width:". ($fait/$total)*100 ."%\"></div>
  </div>";
}
/* Retourne en pourcentage la progression totale de la route */
function getTotalProgress($progress) {
  $totalProgress = array_sum(array_column($progress, 'now'))
                   /array_sum(array_column($progress, 'total'))*100;

  return $totalProgress;
}
function displayProgressPourcent($pourcent){
  echo "<div class=\"pb-text-wrapper\">
    <span>TOTAL</span>
    <span class=\"pb-text\">".$pourcent." %</span>
  </div>
  <div class=\"pb-wrapper\">
    <div class=\"pb-bar\" style=\"width:".$pourcent."%\"></div>
  </div>";
}
?>
<script>
// progressbar.js@1.0.0 version is used
// Docs: http://progressbarjs.readthedocs.org/en/1.0.0/

updateProgress(container_fate, <?php echo round(getTotalProgress($fate_progress))/100 ?>);
updateProgress(container_ubw, <?php echo round(getTotalProgress($ubw_progress))/100 ?>);
updateProgress(container_hf, <?php echo round(getTotalProgress($hf_progress))/100 ?>);
updateProgress(container_pro, 1);
updateProgress(container_le, 0);

function updateProgress(container, $progress) {
  var bar = new ProgressBar.Circle(container, {
    color: '#fff',
    // This has to be the same size as the maximum width to prevent clipping
    strokeWidth: 6,
    trailWidth: 2,
    trailColor: '#2d2d2d',
    easing: 'easeInOut',
    duration: 1400,
    from: { color: 'rgb(5, 67, 149)', width: 2 },
    to: { color: 'rgb(5, 67, 149)', width: 6 },
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
      circle.path.setAttribute('stroke-width', state.width);

      var value = Math.round(circle.value() * 100);
      if (value === 0) {
        circle.setText('');
      } else {
        circle.setText(value);
      }
    }
  });
  bar.text.style.fontFamily = '"Raleway", Helvetica, sans-serif';
  bar.text.style.fontSize = '2rem';
  bar.animate($progress);  // Number from 0.0 to 1.0
}
</script>