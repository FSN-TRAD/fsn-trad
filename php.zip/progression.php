<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Progression</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Pour connaître l'avancement de la traduction, c'est ici.">
    <link rel="stylesheet" href="main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <section id="main">
      <h1>Progression de la traduction</h1>
      <hr/>
      <div id="progression">
        <div id="progression-pro">
          <h2>Prologue</h2>
          <?php displayProgress(3, 3) ?>
        </div>
        <div class="flex-break"></div>
        <div id="progression-fate">
          <h2>Fate</h2>
          <p>Jour 1</p>
          <?php displayProgress(7, 7) ?>
          <p>Jour 2</p>
          <?php displayProgress(5, 5) ?>
          <p>Jour 3</p>
          <?php displayProgress(11, 11) ?>
          <p>Jour 4</p>
          <?php displayProgress(6, 6) ?>
          <p>Jour 5</p>
          <?php displayProgress(6, 6) ?>
          <p>Jour 6</p>
          <?php displayProgress(9, 9) ?>
          <p>Jour 7</p>
          <?php displayProgress(3, 3) ?>
          <p>Jour 8</p>
          <?php displayProgress(5, 5) ?>
          <p>Jour 9</p>
          <?php displayProgress(7, 7) ?>
          <p>Jour 10</p>
          <?php displayProgress(4, 4) ?>
          <p>Jour 11</p>
          <?php displayProgress(10, 10) ?>
          <p>Jour 12</p>
          <?php displayProgress(6, 6) ?>
          <p>Jour 13</p>
          <?php displayProgress(10, 10) ?>
          <p>Jour 14</p>
          <?php displayProgress(7, 7) ?>
          <p>Jour 15</p>
          <?php displayProgress(11, 11) ?>
          <p>Épilogue</p>
          <?php displayProgress(1, 1) ?>
          <p>Tiger Dojo</p>
          <?php displayProgress(14, 14) ?>
          <p>TOTAL</p>
          <?php displayProgressPourcent(100)//123 ?>
        </div>
        <div id="progression-ubw"><h2>Unlimited Blade Works</h2>
          <?php
          $ubw_progress = array(
            ['day' => 'Jour 3', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 4', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 5', 'now' => 10, 'total' => 10],
            ['day' => 'Jour 6', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 7', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 8', 'now' => 7, 'total' => 7],
            ['day' => 'Jour 9', 'now' => 6, 'total' => 6],
            ['day' => 'Jour 10', 'now' => 5, 'total' => 5],
            ['day' => 'Jour 11', 'now' => 2, 'total' => 10],
            ['day' => 'Jour 12', 'now' => 0, 'total' => 8],
            ['day' => 'Jour 13', 'now' => 0, 'total' => 8],
            ['day' => 'Jour 14', 'now' => 8, 'total' => 8],
            ['day' => 'Jour 15', 'now' => 9, 'total' => 9],
            ['day' => 'Jour 16', 'now' => 10, 'total' => 10],
            ['day' => 'Épilogue', 'now' => 0, 'total' => 2],
            ['day' => 'Tiger Dojo', 'now' => 6, 'total' => 10]
          );
          
          // Affiche chaque jour et la barre de progression
          foreach($ubw_progress as $cle => $valeur) {
            echo '<p>' . $ubw_progress[$cle]['day'] . '</p>';
            displayProgress($ubw_progress[$cle]['now'], $ubw_progress[$cle]['total']);
          }
          
          // Affiche le pourcentage de progression
          echo '<p>TOTAL</p>';
          $ubw_total = array_sum(array_column($ubw_progress, 'now'))
                        /array_sum(array_column($ubw_progress, 'total'))*100;
          displayProgressPourcent(round($ubw_total));
          ?>
        </div>
        <div id="progression-hf"><h2>Heaven's Feel</h2>
          <?php
          $hf_progress = array(
            ['day' => 'Jour 4', 'now' => 0, 'total' => 7],
            ['day' => 'Jour 5', 'now' => 0, 'total' => 12],
            ['day' => 'Jour 6', 'now' => 0, 'total' => 9],
            ['day' => 'Jour 7', 'now' => 0, 'total' => 11],
            ['day' => 'Jour 8', 'now' => 0, 'total' => 10],
            ['day' => 'Jour 9', 'now' => 0, 'total' => 14],
            ['day' => 'Jour 10', 'now' => 0, 'total' => 14],
            ['day' => 'Jour 11', 'now' => 0, 'total' => 10],
            ['day' => 'Jour 12', 'now' => 0, 'total' => 7],
            ['day' => 'Jour 13', 'now' => 0, 'total' => 6],
            ['day' => 'Jour 14', 'now' => 0, 'total' => 6],
            ['day' => 'Jour 15', 'now' => 0, 'total' => 13],
            ['day' => 'Jour 16', 'now' => 0, 'total' => 14],
            ['day' => 'Épilogue', 'now' => 0, 'total' => 1],
            ['day' => 'Tiger Dojo', 'now' => 0, 'total' => 16]
          );
          
          // Affiche chaque jour et la barre de progression
          foreach($hf_progress as $cle => $valeur) {
            echo '<p>' . $hf_progress[$cle]['day'] . '</p>';
            displayProgress($hf_progress[$cle]['now'], $hf_progress[$cle]['total']);
          }
          
          // Affiche le pourcentage de progression
          echo '<p>TOTAL</p>';
          $hf_total = array_sum(array_column($hf_progress, 'now'))
                        /array_sum(array_column($hf_progress, 'total'))*100;
          displayProgressPourcent(round($hf_total));
          ?>
        </div>
        <div class="flex-break"></div>
        <div id="progression-le"><h2>Last Episode</h2>
          <?php displayProgress(0, 1) ?>
        </div>
      </div>
    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
<?php
function displayProgress($fait, $total){
  echo "<div class=\"pb-wrapper\">
    <span class=\"pb-text\">".$fait."/".$total."</span>
    <div class=\"pb-bar\" style=\"width:".($fait/$total)*100 ."%\"></div>
  </div>";
}
function displayProgressPourcent($pourcent){
  echo "<div class=\"pb-wrapper\">
    <span class=\"pb-text\">".$pourcent."%</span>
    <div class=\"pb-bar\" style=\"width:".$pourcent."%\"></div>
  </div>";
}
 ?>
