<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Fate/stay night - Traduction Française</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Page d'accueil du projet de traduction en français de Fate/stay night [Réalta Nua].">
    <meta property="og:image" content="https://fsn-trad.github.io/website/images/logo_fsn-trad_small.png" />
	  <meta name="theme-color" content="#0b3f71">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="shortcut icon" href="images/fate-icon.ico"/>
  </head>
  <body>
    <?php include("./banner.php"); ?>
    <?php include("./social.php"); ?>
    <section id="main">
      <h1>Traduction française de Fate/stay night [Réalta Nua] - Ultimate Edition</h1>
      <hr/>
      <p>
        <picture>
					<source srcset="images/cg_saber.webp" type="image/webp">
					<source srcset="images/cg_saber.jpg" type="image/jpg"> 
					<img class="visuel" src="images/cg_saber.jpg" alt="CG Saber" id="img-saber">
				</picture>
        Projet de traduction en français de l'un des visuals novels les plus connus produit par Type-Moon&nbsp;:
        <a href="https://vndb.org/v11" target="_blank" title="VNDB"> Fate/stay night</a>. La traduction est
        réalisée pour fonctionner avec l'<i>
        <a href ="https://forums.nrvnqsr.com/showthread.php/9101-Fate-Stay-Night-Realta-Nua-Ultimate-Edition-2022" target="_blank"> Ultimate Edition</a>
        </i>, qui est une version faite par des fans pour regrouper toutes les routes en un jeu et vous proposer de multiples options.
      </p>
      <p>
        <b>Synopsis&nbsp;: </b>La Guerre du Saint Graal comporte sept Masters qui s'affrontent dans la ville de Fuyuki
        au Japon. À l'aide de leurs pouvoirs magiques et de leurs Servants qu'ils ont préalablement invoqués, le dernier
        d'entre eux pourra s'approprier le Graal et faire exaucer son vœu le plus cher…<br/>
        <span class="push-right">D'après Wikipédia</span>
      </p>

      <br>
      <hr>
      <p>
        Pour plus d'informations, rejoignez notre serveur Discord !
        <a href="https://discord.gg/zGPcfCY" target="_blank" class="discord-text">
    	    <img src="images/logo_discord.svg" id="discord-logo" alt="discord logo">FSN TRAD
  	    </a>
      </p>
    </section>
    <?php include("./footer.php") ?>
  </body>
</html>
