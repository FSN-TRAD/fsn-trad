<header>
  <div id="header-box">
    <nav>
      <ul>
        <li><a href="./">Accueil</a></li>
        <li><a href="./progression.php">Progression</a></li>
        <li><a href="./telechargements.php">Patchs</a></li>
        <li><a href="./a_propos.php">À propos</a></li>
      </ul>
    </nav>
  </div>
</header>
