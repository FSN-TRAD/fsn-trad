<header>
  <div id="header-box">
    <nav>
      <ul>
        <li class="hover-container"><a href="./" class="hover-title">Accueil</a></li>
        <li class="hover-container"><a href="./progression.php" class="hover-title">Progression</a></li>
        <li class="hover-container"><a href="./patch.php" class="hover-title">Patch</a></li>
        <li class="hover-container"><a href="./a_propos.php" class="hover-title">À propos</a></li>
      </ul>
    </nav>
  </div>
</header>