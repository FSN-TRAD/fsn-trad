<div class="social">
  <div class="social-discord">
    <a href="https://discord.gg/zGPcfCY" target="_blank" title="Rejoindre le serveur Discord">
      <img src="images/Discord-Logo-Color.svg">
    </a>
  </div>
  <div class="social-github">
    <a href="https://github.com/FSN-TRAD/FSN-FR/releases" target="_blank" title="Accéder aux patchs">
      <img src="images/GitHub-Logo.svg">
    </a>
  </div>
</div>