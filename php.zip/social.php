<div class="social">
  <div class="social-discord">
    <a href="https://discord.gg/zGPcfCY" target="_blank">
      <img src="images/Discord-Logo-Color">
    </a>
  </div>
  <div class="social-github">
    <a href="https://github.com/FSN-TRAD/FSN-FR/releases" target="_blank">
      <img src="images/Github-Logo">
    </a>
  </div>
</div>