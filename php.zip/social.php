<div class="social">
  <div class="social-discord">
    <a href="https://discord.gg/zGPcfCY" target="_blank" title="Rejoindre le serveur Discord">
      <img src="images/logo_discord.svg">
    </a>
  </div>
  <div class="social-github">
    <a href="https://github.com/FSN-TRAD/FSN-FR/releases" target="_blank" title="Accéder aux patchs">
      <img src="images/logo_github.svg">
    </a>
  </div>
  <div class="social-youtube">
    <a href="https://www.youtube.com/watch?v=9dZbwFyim20&list=PLZoKEkWJICOE4X-0YUScSmIHpKDMSb54g&ab_channel=alucardonacmono" target="_blank" title="Mises au point YouTube">
      <img src="images/logo_youtube.svg">
    </a>
  </div>
</div>